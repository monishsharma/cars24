export const SET_LOADER = 'SET_LOADER';
export const UNSET_LOADER = 'UNSET_LOADER';
export const STORE_PRODUCTS = 'STORE_PRODUCTS';